# re_rassor_cartography

High-performance C++ obstacle map for RE-RASSOR using a quadtree spatial data structure.

This is a header-only library that provides O(log n) obstacle lookups, real-time add/remove, area-obstruction checks, and nearby-obstacle queries — fast enough for kHz-rate control loops. It replaces an earlier Python implementation.

Table of contents:

- [Prereqs](#prereqs)
- [Setup](#setup)
- [Running](#running)
- [API](#api)
- [Further documentation](#further-documentation)
- [Contributing](#contributing)
- [License](#license)

---

## Prereqs

1. A working ROS 2 workspace (Humble or newer) with `colcon` and `ament_cmake` available.
1. A C++17-capable toolchain (`g++` or `clang++`).
1. (Optional) GoogleTest for the unit-test target — pulled in automatically via `ament_cmake_gtest` when `BUILD_TESTING=ON`.

The package has no external runtime dependencies — the quadtree is self-contained under [include/quadtree/](include/quadtree/).

---

## Setup

Clone the parent repository and place this package inside the `src/` directory of your colcon workspace (it already lives there in this repo):

```sh
cd <your_ros2_ws>
colcon build --packages-select re_rassor_cartography
source install/setup.bash
```

To also build the bundled examples, pass `-DBUILD_EXAMPLES=ON`:

```sh
colcon build --packages-select re_rassor_cartography --cmake-args -DBUILD_EXAMPLES=ON
```

To use the library from another package, add `re_rassor_cartography` to that package's `package.xml` (`<depend>`) and `CMakeLists.txt` (`find_package` + `ament_target_dependencies`), then include the header:

```cpp
#include "quadtree/QuadtreeObstacleMap.h"
using namespace quadtree;
```

---

## Running

### Examples

After building with `-DBUILD_EXAMPLES=ON`:

```sh
ros2 run re_rassor_cartography obstacle_map_example
ros2 run re_rassor_cartography simple_test
```

### Tests

```sh
colcon test --packages-select re_rassor_cartography
colcon test-result --verbose
```

### Minimal usage

```cpp
#include "quadtree/QuadtreeObstacleMap.h"
using namespace quadtree;

// 100×100 m world centred at the origin, default obstacle size 0.5 m
QuadtreeObstacleMap<float> map(0.0f, 0.0f, 100.0f, 100.0f, 0.5f);

map.addObstacle(2.0f, 3.0f);                  // from a sensor sample
if (map.isAreaObstructed(targetX, targetY)) { /* re-plan */ }

auto nearby = map.getNearbyObstaclesCircular(robotX, robotY, 5.0f);
```

For an end-to-end ROS 2 integration sketch (LaserScan → obstacle map → path-clear check), see [examples/obstacle_map_example.cpp](examples/obstacle_map_example.cpp).

---

## API

`QuadtreeObstacleMap<T>` (defined in [include/quadtree/QuadtreeObstacleMap.h](include/quadtree/QuadtreeObstacleMap.h)):

| Method | Description |
|---|---|
| `addObstacle(x, y, size)` | Insert an obstacle at `(x, y)`. `size` is optional and defaults to the map's default. |
| `removeObstacle(x, y)` | Remove the obstacle at `(x, y)`. Returns `bool`. |
| `isAreaObstructed(x, y, tolerance)` | Check if the area around `(x, y)` is blocked. |
| `getNearbyObstacles(x, y, radius)` | Obstacles inside the bounding box of side `2 * radius`. |
| `getNearbyObstaclesCircular(x, y, radius)` | Obstacles strictly inside the circle of radius `radius`. |
| `clear()` | Remove all obstacles. |
| `getObstacleCount()` | Total number of obstacles. |
| `getWorldBox()` | World bounds as a `Box`. |

Supporting types live in [Box.h](include/quadtree/Box.h), [Vector2.h](include/quadtree/Vector2.h), and [Quadtree.h](include/quadtree/Quadtree.h).

---

## Further documentation

- [TESTING_GUIDE.md](TESTING_GUIDE.md) — how to run and extend the GoogleTest suite.
- [IMPLEMENTATION_NOTES.md](IMPLEMENTATION_NOTES.md) — design rationale and performance notes.

---

## Contributing

For a basic rundown on how to contribute to this project using Git and GitHub, see the top-level repository contribution guide.

---

## License

MIT License. The underlying quadtree is adapted from Pierre Vigier's implementation (https://github.com/pvigier/Quadtree), also MIT.
