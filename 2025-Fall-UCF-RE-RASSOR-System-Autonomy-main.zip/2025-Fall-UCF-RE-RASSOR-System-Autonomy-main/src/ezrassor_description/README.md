# ezrassor_description

URDF description and TF tree for the RE-RASSOR rover.

This package owns the robot model — body geometry, depth-camera placement, and the virtual `laser_frame` used for the `/scan` topic — and ships a `robot_state_publisher` launch file that broadcasts the full TF tree from the xacro file.

Table of contents:

- [Prereqs](#prereqs)
- [Setup](#setup)
- [Running](#running)
- [TF tree](#tf-tree)
- [Customising the model](#customising-the-model)
- [Contributing](#contributing)
- [License](#license)

---

## Prereqs

1. A ROS 2 workspace (Humble or newer) with `colcon` and `ament_cmake`.
1. The following ROS 2 packages (declared in [package.xml](package.xml)):
    - `robot_state_publisher`
    - `xacro`
    - `joint_state_publisher`

These are part of the standard ROS 2 desktop install — `sudo apt install ros-${ROS_DISTRO}-{robot-state-publisher,xacro,joint-state-publisher}` if missing.

---

## Setup

Place this package under `src/` in your colcon workspace (already done in this repo) and build it:

```sh
cd <your_ros2_ws>
colcon build --packages-select ezrassor_description
source install/setup.bash
```

The build installs the `urdf/` and `launch/` directories into `share/ezrassor_description/`, which is where the launch file looks them up at runtime.

---

## Running

### Standalone

Bring up just `robot_state_publisher` against the EZRASSOR URDF:

```sh
ros2 launch ezrassor_description robot_state_publisher.launch.py
```

This publishes the full static TF tree to `/tf_static` and the `robot_description` parameter that downstream tools (RViz, Nav2, etc.) read.

### As part of the autonomy stack

The full bringup ([src/re_rassor_bringup](../re_rassor_bringup)) launches `robot_state_publisher` together with the rest of the stack — see that package's README for details. You generally do **not** want to run both at once.

### Inspecting the model

```sh
# Render the xacro to plain URDF
xacro $(ros2 pkg prefix ezrassor_description)/share/ezrassor_description/urdf/ezrassor.urdf.xacro

# Visualise in RViz (pair with the launch file above)
ros2 run rviz2 rviz2
```

---

## TF tree

```
base_footprint
└── base_link
    └── camera_link
        ├── camera_depth_frame    (optical: Z forward, X right, Y down)
        ├── camera_color_frame    (optical: used by YOLO / RGB processing)
        └── laser_frame           (virtual; depthimage_to_laserscan publishes /scan here)
```

Primary sensor is the **Orbbec Astra Pro** depth camera mounted at the front of the rover. There is no physical LiDAR — `/scan` is generated from the depth image via `depthimage_to_laserscan`, and `laser_frame` exists so downstream consumers (`rf2o_laser_odometry`, Nav2 costmaps) can reference a stable laser frame regardless of the underlying source.

---

## Customising the model

Geometry and sensor placement are exposed as xacro properties at the top of [urdf/ezrassor.urdf.xacro](urdf/ezrassor.urdf.xacro):

| Property | Default | Meaning |
|---|---|---|
| `body_length`, `body_width`, `body_height` | `0.6, 0.6, 0.3` m | Bounding box of the rover body. |
| `ground_clearance` | `0.15` m | Offset from `base_footprint` to the bottom of `base_link`. |
| `camera_x`, `camera_y`, `camera_z` | `0.3, 0.0, 0.1` m | Depth-camera position relative to `base_link`. |

After editing the xacro, rebuild the package (`colcon build --packages-select ezrassor_description`) and relaunch `robot_state_publisher`.

---

## Contributing

For a basic rundown on how to contribute to this project using Git and GitHub, see the top-level repository contribution guide.

---

## License

MIT License.
