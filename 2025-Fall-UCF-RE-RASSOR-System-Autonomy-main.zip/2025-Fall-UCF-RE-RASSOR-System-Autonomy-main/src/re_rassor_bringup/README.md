# re_rassor_bringup

Top-level launch and configuration package for the RE-RASSOR autonomy stack.

This package wires the rover's sensors, motor controllers, odometry, SLAM, and Nav2 together. It does not contain runtime nodes of its own — it composes nodes from other packages via launch files in [launch/](launch/) and YAML configs in [config/](config/).

Table of contents:

- [Prereqs](#prereqs)
- [Setup](#setup)
- [Running](#running)
- [Launch files](#launch-files)
- [Config files](#config-files)
- [System architecture](#system-architecture)
- [Contributing](#contributing)
- [License](#license)

---

## Prereqs

1. A ROS 2 workspace (Humble or newer) with `colcon` and `ament_cmake`.
1. The autonomy-stack packages in this repo built and on the workspace overlay:
    - `re_rassor_motor_controller`
    - `re_rassor_mission_control`
    - `re_rassor_controller_server`
    - `re_rassor_yolo_detector`
    - `ezrassor_description`
1. ROS 2 dependencies (declared in [package.xml](package.xml)):
    - `nav2_bringup`, `nav2_common`, `nav2_util`
    - `slam_toolbox`
    - `robot_state_publisher`, `tf2_ros`
    - `openni2_camera`, `depth_image_proc`, `depthimage_to_laserscan`
1. Hardware (for `re_rassor_full.launch.py` only):
    - Two Arduinos exposed at `/dev/arduino_wheel` and `/dev/arduino_drum`
    - Orbbec Astra Pro depth camera on USB
1. A workspace-root `fake_map.py` (and `demo_sim.py` for the dev-machine launch); the launch files walk up from `share/` to find them.

Install missing ROS 2 packages with `sudo apt install ros-${ROS_DISTRO}-<pkg>`.

---

## Setup

Place this package under `src/` of your colcon workspace (already done in this repo) and build it together with its siblings:

```sh
cd <your_ros2_ws>
colcon build
source install/setup.bash
```

For an iterative loop on just this package:

```sh
colcon build --packages-select re_rassor_bringup
source install/setup.bash
```

---

## Running

### On the rover (full hardware stack)

```sh
ros2 launch re_rassor_bringup re_rassor_full.launch.py
```

Optional arguments:

| Arg | Default | Description |
|---|---|---|
| `wheel_port` | `/dev/arduino_wheel` | Serial port for the wheel Arduino. |
| `drum_port` | `/dev/arduino_drum` | Serial port for the drum/shoulder Arduino. |
| `baud_rate` | `115200` | Serial baud rate. |
| `rviz` | `false` | Set `true` to also launch RViz2. |

Example with RViz and a non-default wheel port:

```sh
ros2 launch re_rassor_bringup re_rassor_full.launch.py rviz:=true wheel_port:=/dev/ttyUSB0
```

### On a dev machine (no hardware)

Replaces motor + camera + SLAM with a fake simulator and a static `map → odom` TF, but runs the rest (Nav2, mission control, controller server) for real:

```sh
ros2 launch re_rassor_bringup demo_sim.launch.py
```

You can then connect the Electron controller app at the dev machine's IP, port 5000.

### Other launch entry points

- `autonomy.launch.py` — Nav2 + mission control only, against an existing map. Useful when SLAM is run separately or replaying a bag.
- `odometry.launch.py` — wheel + visual odometry pipeline only. Useful for tuning odometry without bringing up Nav2.
- `sensors.launch.py` — depth-camera composable container only (OpenNI2 + `depth_image_proc`). Useful for camera bring-up and TF debugging.

---

## Launch files

| File | Purpose |
|---|---|
| [launch/re_rassor_full.launch.py](launch/re_rassor_full.launch.py) | Full hardware stack: motor controller, Astra camera, depth → pointcloud + laser-scan, mission control, slam_toolbox, Nav2, optional RViz. Staggers startup with `TimerAction` so TF and odometry are ready before SLAM and Nav2 come up. |
| [launch/demo_sim.launch.py](launch/demo_sim.launch.py) | Dev-machine equivalent of the full stack — replaces hardware with `demo_sim.py` (fake motor + empty point cloud) and uses a static `map → odom` TF instead of SLAM. |
| [launch/autonomy.launch.py](launch/autonomy.launch.py) | Nav2 + mission_control + (optional) `robot_state_publisher`, `initial_pose_pub`, `nav2_client`. Exposes `use_sim_time`, `map`, `params_file`, and goal pose args. |
| [launch/odometry.launch.py](launch/odometry.launch.py) | Wheel + visual odometry pipeline (used by the launches above). |
| [launch/sensors.launch.py](launch/sensors.launch.py) | Composable container running `openni2_camera` + `depth_image_proc` for the Astra Pro. |

---

## Config files

| File | Used by |
|---|---|
| [config/nav2_params.yaml](config/nav2_params.yaml) | Nav2 stack — controller, planner, costmaps, BT navigator, velocity smoother, lifecycle manager. |
| [config/slam_toolbox_params.yaml](config/slam_toolbox_params.yaml) | `async_slam_toolbox_node` — laser-based 2D SLAM. |
| [config/rf2o_params.yaml](config/rf2o_params.yaml) | `rf2o_laser_odometry` — laser-scan-based odometry (used by `odometry.launch.py`). |

---

## System architecture

The full launch wires the following data flow:

```
Astra Pro depth camera
    └── /camera/depth/image_raw + /camera/depth/camera_info
            ├── depth_image_proc        → /camera/depth/points    (Nav2 costmaps)
            └── depthimage_to_laserscan → /scan                   (slam_toolbox)

Arduinos (wheel + drum)
    └── serial_motor_controller → /odometry/wheel

mission_control (fuses wheel + visual odom)
    ├── /odometry/fused
    └── TF: odom → base_link

slam_toolbox
    ├── /map
    └── TF: map → odom

Nav2 (planner + controller + behaviours + BT) → /cmd_vel → motor controller
```

Static TFs published from the launch file:

- `base_link → camera_link` (0.15 m forward, 0.10 m up, 5° downward pitch)
- `camera_link → camera_depth_optical_frame` (REP-103 optical convention)

The full URDF-based TF tree (with `base_footprint`, `laser_frame`, etc.) lives in [ezrassor_description](../ezrassor_description) and is launched separately via `robot_state_publisher.launch.py`.

Startup order is gated by `TimerAction` because Nav2 and SLAM need the rest of the system to be publishing before they initialise:

| t (s) | What starts |
|---|---|
| 0 | Static TFs, fake_map (latched blank `/map`), motor controller, Astra camera, depth → pointcloud, depth → laserscan |
| 5 | `mission_control` (publishes `odom → base_link`) |
| 6 | `slam_toolbox` (needs TF + `/scan`) |
| 12 | Nav2 (needs `/map` + `map → odom`) |
| 13 | RViz (optional) |

---

## Contributing

For a basic rundown on how to contribute to this project using Git and GitHub, see the top-level repository contribution guide.

---

## License

Apache-2.0.
